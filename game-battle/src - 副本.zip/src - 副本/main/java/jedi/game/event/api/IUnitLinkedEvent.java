package jedi.game.event.api;

import jedi.game.player.IEntity;

public interface IUnitLinkedEvent {
    IEntity getEntity();
}
